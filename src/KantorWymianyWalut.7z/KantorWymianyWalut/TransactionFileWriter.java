package KantorWymianyWalut;

import java.io.FileWriter;
import java.io.IOException;

public class TransactionFileWriter {

    private FileWriter fileWriter;
    private String fileName;

    public TransactionFileWriter(String fileName) throws IOException {
        this.fileName = fileName;
        this.fileWriter = new FileWriter(fileName);
    }

    public void storeToFile() throws IOException{
        fileWriter.write("aaaaaa");

    }
}
